import org.opensim.modeling.*

% Load and initialize the model
model = Model('/Users/kendricktate/Documents/MATLAB/OSIM Outputs/KinovaGen3WithBio.osim');
state = model.initSystem();

% Get the body (e.g., 'hand')
Base_link = model.getBodySet().get(['hand']);

% Define the point in the body frame (e.g., Vec3(0, 0, 0) for origin)
pointInHand = Vec3(0, 0, 0);  % or wherever the end-effector is located

% Transform to ground frame
pointInGround = Base_link.findStationLocationInGround(state, pointInHand);

% Print or inspect the result
x = pointInGround.get(0);
y = pointInGround.get(1);
z = pointInGround.get(2);
fprintf('End-effector point in ground frame: (%.3f, %.3f, %.3f)\n', x, y, z);