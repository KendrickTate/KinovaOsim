import org.opensim.modeling.*;

% Load the Bio Arm model
model = Model('/Users/kendricktate/Downloads/ArmRobotModel4.1/ModelGeneration/ArmSubject1.osim');


%Set the initial position
Shoulder_Elv = model.getCoordinateSet().get('shoulder_elv');
Shoulder_Elv.set_default_value(pi()/2);  
Shoulder_Rot = model.getCoordinateSet().get('shoulder_rot');
Shoulder_Rot.set_default_value(pi()/2);
Bio_height = model.getCoordinateSet().get('t_y');
Bio_height.set_default_value(0.6075);  
Bio_offset = model.getCoordinateSet().get('t_x');
Bio_offset.set_default_value(0.09);  


%% Create Links

% Base link
mass = 1.697;
com = Vec3(-0.000648, -0.000166, 0.084487);
inertia = Inertia(0.004622, 9E-06, 6E-05, 0.004495, 9E-06, 0.002079);
Base_link = Body('Base_link', mass, com, inertia);
Base_link.attachGeometry(Mesh('/Users/kendricktate/Documents/MATLAB/KINOVA MODELS/GEN3_6DOF_NO-VISION_V01 parts - GEN3 SIMPLIFIED BASE.obj'));

% Shoulder link
mass = 1.377;
com = Vec3(-2.3E-05, -0.010364, -0.07336);
inertia = Inertia(0.00457, 1E-06, 2E-06, 0.004831, 0.000448, 0.001409);
Shoulder_link = Body('Shoulder_link', mass, com, inertia);
Shoulder_link.attachGeometry(Mesh('/Users/kendricktate/Documents/MATLAB/KINOVA MODELS/GEN3 SIMPLIFIED SHOULDER.obj'));

% Bicep link
mass = 1.262;
com = Vec3(3.5E-05, -0.208207, -0.01889);
inertia = Inertia(0.046752, -9E-06, 0, 0.00085, -9.8E-05, 0.047188);
Bicep_link = Body('Bicep_link', mass, com, inertia);
Bicep_link.attachGeometry(Mesh('/Users/kendricktate/Documents/MATLAB/KINOVA MODELS/GEN3 SIMPLIFIED BICEP.obj'));

% Forearm link
mass = 0.93;
com = Vec3(1.8E-05, 0.076168, -0.01397);
inertia = Inertia(0.008292, -1E-06, 0, 0.000628, 0.000432, 0.008464);
Forearm_link = Body('Forearm_link', mass, com, inertia);
Forearm_link.attachGeometry(Mesh('/Users/kendricktate/Documents/MATLAB/KINOVA MODELS/GEN3 SIMPLIFIED Forearm.obj'));

% Spherical wrist 1 link
mass = 0.6781;
com = Vec3(-1E-06, 0.008486, -0.062937);
inertia = Inertia(0.001645, 0, 0, 0.001666, -0.000234, 0.000389);
Spherical_wrist_1_link = Body('Spherical_wrist_1_link', mass, com, inertia);
Spherical_wrist_1_link.attachGeometry(Mesh('/Users/kendricktate/Documents/MATLAB/KINOVA MODELS/GEN3 SIMPLIFIED Spherical Wrist1.obj'));

% Spherical wrist 2 link
mass = 0.678;
com = Vec3(-1E-06, 0.046429, -0.008704);
inertia = Inertia(0.001685, 0, 0, 0.0004, 0.000255, 0.001696);
Spherical_wrist_2_link = Body('Spherical_wrist_2_link', mass, com, inertia);
Spherical_wrist_2_link.attachGeometry(Mesh('/Users/kendricktate/Documents/MATLAB/KINOVA MODELS/GEN3 SIMPLIFIED Spherical Wrist2.obj'));

% End Effector link
mass = 0.5;
com = Vec3(0.000281, 0.011402, -0.029798);
inertia = Inertia(0.000587, 3E-06, 3E-06, 0.000369, -0.000118, 0.000609);
End_effector_link = Body('End_effector_link', mass, com, inertia);
End_effector_link.attachGeometry(Mesh('/Users/kendricktate/Documents/MATLAB/KINOVA MODELS/GEN3 SIMPLIFIED No-Vision.obj'));

% Handle Model
mass = 0.10373;
com = Vec3(0.000281, 0.011402, -0.029798);
inertia = Inertia(0.000587, 3E-06, 3E-06, 0.000369, -0.000118, 0.000609);
KinovaHandle_link = Body('KinovaHandle', mass, com, inertia);
KinovaHandle_link.attachGeometry(Mesh('/Users/kendricktate/Documents/MATLAB/KINOVA MODELS/KinovaHandle.obj'));

%% Create Joints

% Establish Hand from Bio Model
Hand = model.get_BodySet().get('hand');

% Establish Ground
ground = model.getGround();

% Base_Shoulder Joint
locationInParent_8    = Vec3(0, 0.15805, 0);
orientationInParent_8 = Vec3(pi()/2, 0, 0); %pi()/2, pi()/2, 0
locationInChild_8     = Vec3(0, 0, 0);
orientationInChild_8  = Vec3(0, -pi()/2, 0);
Base_Shoulder = PinJoint('Base_Shoulder',...           % Joint Name
                        Base_link,...         % Parent Frame (Ground)
                        locationInParent_8,...       % Translation in Parent Frame
                        orientationInParent_8,...    % Orientation in Parent Frame
                        Shoulder_link,...     % Child Frame
                        locationInChild_8,...        % Translation in Child Frame
                        orientationInChild_8);       % Orientation in Child Frame

% Shoulder_Bicep Joint
locationInParent_7    = Vec3(0.126, 0, 0); %(0.33, 0.005375, 0)
orientationInParent_7 = Vec3(pi()/2, 0, 0);
locationInChild_7     = Vec3(-.205, 0, 0);
orientationInChild_7  = Vec3(pi()/2, 0, 0);
Shoulder_Bicep = PinJoint('Shoulder_Bicep',... =          % Joint Name
                        Shoulder_link,...     % Parent Frame
                        locationInParent_7,...       % Translation in Parent Frame
                        orientationInParent_7,...    % Orientation in Parent Frame
                        Bicep_link,...        % Child Frame
                        locationInChild_7,...        % Translation in Child Frame
                        orientationInChild_7);       % Orientation in Child Frame

% Bicep_Forearm Joint
locationInParent_6    = Vec3(.205, 0, 0); %0, -0.41, 0
orientationInParent_6 = Vec3(pi()/2, 0, 0);
locationInChild_6    = Vec3(0, 0, 0);
orientationInChild_6  = Vec3(pi()/2, 0, 0);
Bicep_Forearm = PinJoint('Bicep_Forearm',...           % Joint Name
                        Bicep_link,...        % Parent Frame
                        locationInParent_6,...       % Translation in Parent Frame
                        orientationInParent_6,...    % Orientation in Parent Frame
                        Forearm_link,...      % Child Frame
                        locationInChild_6,...        % Translation in Child Frame
                        orientationInChild_6);       % Orientation in Child Frame

% Forearm_Wrist1 Joint
locationInParent_5    = Vec3(.209975, 0, 0); %0, 0.20843, -0.006375
orientationInParent_5 = Vec3(0, pi()/2, 0);
locationInChild_5     = Vec3(0, 0, 0);
orientationInChild_5 = Vec3(0, pi()/2, 0);
Forearm_Wrist1 = PinJoint('Forearm_Wrist1',...           % Joint Name
                        Forearm_link,...      % Parent Frame
                        locationInParent_5,...       % Translation in Parent Frame
                        orientationInParent_5,...    % Orientation in Parent Frame
                        Spherical_wrist_1_link,...  % Child Frame
                        locationInChild_5,...        % Translation in Child Frame
                        orientationInChild_5);       % Orientation in Child Frame

% Wrist1_Wrist2 Joint
locationInParent_4    = Vec3(.1035, 0, 0); %.207, 0, 0
orientationInParent_4 = Vec3(pi()/2, 0, 0);
locationInChild_4    = Vec3(.1035, 0, 0);
orientationInChild_4  = Vec3(pi()/2, pi(), 0);
Wrist1_Wrist2 = PinJoint('Wrist1_Wrist2',...           % Joint Name
                        Spherical_wrist_1_link,...  % Parent Frame
                        locationInParent_4,...       % Translation in Parent Frame
                        orientationInParent_4,...    % Orientation in Parent Frame
                        Spherical_wrist_2_link,...  % Child Frame
                        locationInChild_4,...        % Translation in Child Frame
                        orientationInChild_4);       % Orientation in Child Frame

% Wrist2_EndEffector Joint
locationInParent_3    = Vec3(0, 0, 0);
orientationInParent_3 = Vec3(pi(), 0, 0);
locationInChild_3     = Vec3(0, 0, 0);
orientationInChild_3  = Vec3(0, pi()/2, 0);
Wrist2_EndEffector = PinJoint('Wrist2_EndEffector',...           % Joint Name
                        End_effector_link,...  % Parent Frame
                        locationInParent_3,...       % Translation in Parent Frame
                        orientationInParent_3,...    % Orientation in Parent Frame
                        Spherical_wrist_2_link,...     % Child Frame
                        locationInChild_3,...        % Translation in Child Frame
                        orientationInChild_3);       % Orientation in Child Frame

% EndEffector_Handle Joint
locationInParent_2    = Vec3(0, 0, -0.061525);
orientationInParent_2 = Vec3(0, 0, 0);
locationInChild_2     = Vec3(0, 0, 0);
orientationInChild_2  = Vec3(0, 0, 0);
EndEffector_Handle = PinJoint('EndEffector_Handle',...  % Joint Name
                                    KinovaHandle_link,...     % Parent Frame
                                    locationInParent_2,...      % Translation in Parent Frame
                                    orientationInParent_2,...   % Orientation in Parent Frame
                                    End_effector_link,... % Child Frame
                                    locationInChild_2,...       % Translation in Child Frame
                                    orientationInChild_2);      % Orientation in Child Frame


% Human Robot Interaction Joint
% 3.0341   -1.5614    1.5220
X_l = -0.021424;
Y_l = 0.008138;
Z_l = 0.130683;
x = 3.0341;
y = -1.5614;
z = 1.5220;
locationInParent_1    = Vec3(X_l, Y_l, Z_l);
orientationInParent_1 = Vec3(x,   y,   z);
locationInChild_1     = Vec3(0, 0, 0);
orientationInChild_1  = Vec3(0, 0, 0);
HRI_Joint = WeldJoint('HRI',...  % Joint Name
                                    KinovaHandle_link,...     % Parent Frame
                                    locationInParent_1,...      % Translation in Parent Frame
                                    orientationInParent_1,...   % Orientation in Parent Frame
                                    Hand,... % Child Frame
                                    locationInChild_1,...       % Translation in Child Frame
                                    orientationInChild_1);      % Orientation in Child Frame

% Constrain the Base to the Ground
locationInParent_0    = Vec3(0, 0, .75);
orientationInParent_0 = Vec3(0, -pi()/2, 0);
locationInChild_0     = Vec3(0, 0, 0);
orientationInChild_0  = Vec3(0, 0, 0);
weld = WeldConstraint('ground_to_base',...  % Constraint Name
                                    ground,...     % Parent Frame
                                    locationInParent_0,...      % Translation in Parent Frame
                                    orientationInParent_0,...   % Orientation in Parent Frame
                                    Base_link,... % Child Frame
                                    locationInChild_0,...       % Translation in Child Frame
                                    orientationInChild_0);      % Orientation in Child Frame
% Establish Thorax Body
Thorax = model.getBodySet().get('thorax');

% Constrain the Thorax to the Ground
locationInParent_01    = Vec3(0.09, .6075, 0);
orientationInParent_01 = Vec3(0, 0, 0);
locationInChild_01     = Vec3(0, 0, 0);
orientationInChild_01  = Vec3(0, 0, 0);
weld2 = WeldConstraint('thorax_to_ground',...  % Constraint Name
                                    ground,...     % Parent Frame
                                    locationInParent_01,...      % Translation in Parent Frame
                                    orientationInParent_01,...   % Orientation in Parent Frame
                                    Thorax,... % Child Frame
                                    locationInChild_01,...       % Translation in Child Frame
                                    orientationInChild_01);      % Orientation in Child Frame

% Constrain the Thorax to the Ground
locationInParent_02    = Vec3(0.265289, -.573089, -.75);
orientationInParent_02 = Vec3(0, 0, 0);
locationInChild_02     = Vec3(0, 0, 0);
orientationInChild_02  = Vec3(0, 0, 0);
weld3 = WeldConstraint('thorax_to_base',...  % Constraint Name
                                    Thorax,...     % Parent Frame
                                    locationInParent_02,...      % Translation in Parent Frame
                                    orientationInParent_02,...   % Orientation in Parent Frame
                                    Base_link,... % Child Frame
                                    locationInChild_02,...       % Translation in Child Frame
                                    orientationInChild_02);      % Orientation in Child Frame

% Add the bodies and joints to the model

model.addBody(Base_link);
model.addBody(Shoulder_link);
model.addBody(Bicep_link);
model.addBody(Forearm_link);
model.addBody(Spherical_wrist_1_link);
model.addBody(Spherical_wrist_2_link);
model.addBody(End_effector_link);
model.addBody(KinovaHandle_link);

model.addJoint(Base_Shoulder);
model.addJoint(Shoulder_Bicep);
model.addJoint(Bicep_Forearm);
model.addJoint(Forearm_Wrist1);
model.addJoint(Wrist1_Wrist2);
model.addJoint(Wrist2_EndEffector);
model.addJoint(EndEffector_Handle);
model.addJoint(HRI_Joint);

model.addConstraint(weld);
model.addConstraint(weld2);
model.addConstraint(weld3);

% Finalize the model
model.finalizeConnections();

%% Establish Kinova Default Configuration

EndEffector_Handle = model.getCoordinateSet().get('EndEffector_Handle_coord_0');
EndEffector_Handle.set_default_value(0); 
Bicep_Forearm = model.getCoordinateSet().get('Bicep_Forearm_coord_0');
Bicep_Forearm.set_default_value(-pi()/2); 
Shoulder_Bicep = model.getCoordinateSet().get('Shoulder_Bicep_coord_0');
Shoulder_Bicep.set_default_value(deg2rad(-2.5)); 
Wrist2_EndEffector = model.getCoordinateSet().get('Wrist2_EndEffector_coord_0');
Wrist2_EndEffector.set_default_value(deg2rad(-6)); 

%% Final finalize
model.finalizeConnections();

%% Model Output
outputDir = '/Users/kendricktate/Documents/MATLAB/OSIM Outputs';
outputFilePath = fullfile(outputDir, 'KinovaGen3WithBio.osim');
model.print(outputFilePath);


disp('OSIM model has been successfully created.');

