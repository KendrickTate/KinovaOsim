clc; clear;
import org.opensim.modeling.*

% Load your model
model = Model('/Users/kendricktate/Documents/MATLAB/OSIM Outputs/KinovaGen3WithBio.osim');
state = model.initSystem();

% Get the two bodies
parent = model.getBodySet().get('thorax');   % Change as needed
child  = model.getBodySet().get(['Base_link']); % Change as needed

X_G_P = parent.getTransformInGround(state);
X_G_C = child.getTransformInGround(state);

p_G_P = X_G_P.p();
p_G_C = X_G_C.p();

R_G_P_osim = X_G_P.R();

% Convert OpenSim Rotation to MATLAB matrix
R_G_P = zeros(3,3);
for i=0:2
    for j=0:2
        R_G_P(i+1,j+1) = R_G_P_osim.get(i,j);
    end
end

% Convert Vec3 to MATLAB vectors
p_G_P_vec = [p_G_P.get(0); p_G_P.get(1); p_G_P.get(2)];
p_G_C_vec = [p_G_C.get(0); p_G_C.get(1); p_G_C.get(2)];

% Compute child's origin in parent's frame
p_P_C = R_G_P' * (p_G_C_vec - p_G_P_vec);

fprintf('Child origin in parent frame:\nX: %.6f\nY: %.6f\nZ: %.6f\n', p_P_C);