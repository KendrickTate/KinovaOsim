import org.opensim.modeling.*

% Load model
model = Model('/Users/kendricktate/Documents/MATLAB/OSIM Outputs/KinovaGen3WithBio.osim');
state = model.initSystem();

% Set the name of the body you're interested in
bodyName = 'KinovaHandle';  % e.g., 'femur_r'

% Get the body and its transform in ground
body = model.getBodySet().get(bodyName);
X_G_B = body.getTransformInGround(state);  % Transform from body to ground
R_G_B = X_G_B.R();  % Rotation part

% Convert rotation to MATLAB matrix
R = zeros(3,3);
for i = 0:2
    for j = 0:2
        R(i+1,j+1) = R_G_B.get(i,j);
    end
end

% Extract XYZ Euler angles (body-fixed rotation)
% Assumes the XYZ fixed-angle convention (intrinsic rotations)
% Convert rotation matrix to XYZ angles (in radians)
% MATLAB default order: ZYX → need custom implementation for XYZ

% Safely compute the XYZ angles
if abs(R(3,1)) < 1
    theta_y = -asin(R(3,1));
    theta_x = atan2(R(3,2)/cos(theta_y), R(3,3)/cos(theta_y));
    theta_z = atan2(R(2,1)/cos(theta_y), R(1,1)/cos(theta_y));
else
    % Gimbal lock case
    theta_y = -asin(R(3,1));
    theta_x = atan2(-R(2,3), R(2,2));
    theta_z = 0;
end

% Orientation vector in radians (XYZ)
orientationVec = [theta_x, theta_y, theta_z];  % 1×3

% Convert to degrees if needed
orientationDeg = rad2deg(orientationVec);

disp('Orientation relative to ground (XYZ in radians):');
disp(orientationVec);

disp('Orientation relative to ground (XYZ in degrees):');
disp(orientationDeg);