
import org.opensim.modeling.*

% Load your model
model = Model('/Users/kendricktate/Documents/MATLAB/OSIM Outputs/KinovaGen3WithBio.osim');
state = model.initSystem();

% Get the two bodies
parent = model.getBodySet().get('KinovaHandle');   % Change as needed
child  = model.getBodySet().get(['hand']); % Change as needed

% Get transforms in ground
X_G_P = parent.getTransformInGround(state);
X_G_C = child.getTransformInGround(state);

% Extract OpenSim rotation objects
R_G_P_osim = X_G_P.R();
R_G_C_osim = X_G_C.R();

% Convert OpenSim rotations to MATLAB numeric 3x3 matrices
R_G_P = zeros(3,3);
R_G_C = zeros(3,3);
for i = 0:2
    for j = 0:2
        R_G_P(i+1,j+1) = R_G_P_osim.get(i,j);
        R_G_C(i+1,j+1) = R_G_C_osim.get(i,j);
    end
end

% Compute rotation of child in parent frame
R_P_C = R_G_P' * R_G_C;

% Display result
disp('Rotation of child in parent frame (R_P_C):');
disp(R_P_C);

if abs(R_P_C(3,1)) < 1
    theta_y = -asin(R_P_C(3,1));
    theta_x = atan2(R_P_C(3,2), R_P_C(3,3));
    theta_z = atan2(R_P_C(2,1), R_P_C(1,1));
else
    % Gimbal lock case
    theta_y = -pi/2 * sign(R_P_C(3,1));
    theta_x = atan2(-R_P_C(1,2), R_P_C(2,2));
    theta_z = 0;
end

% Final orientation vector (in radians)
orientationVec = [theta_x, theta_y, theta_z]