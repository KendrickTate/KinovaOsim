import org.opensim.modeling.*;

% Define the model
model = Model();

%% Links

% Left base link
mass = 1.697;
com = Vec3(-0.000648, -0.000166, 0.084487);
inertia = Inertia(0.004622, 9E-06, 6E-05, 0.004495, 9E-06, 0.002079);
left_base_link = Body('left_base_link', mass, com, inertia);
left_base_link.attachGeometry(Mesh('MESH FILE LOCATION'));

% Left shoulder link
mass = 1.377;
com = Vec3(-2.3E-05, -0.010364, -0.07336);
inertia = Inertia(0.00457, 1E-06, 2E-06, 0.004831, 0.000448, 0.001409);
left_shoulder_link = Body('left_shoulder_link', mass, com, inertia);
left_shoulder_link.attachGeometry(Mesh('MESH FILE LOCATION'));

% Left bicep link
mass = 1.262;
com = Vec3(3.5E-05, -0.208207, -0.01889);
inertia = Inertia(0.046752, -9E-06, 0, 0.00085, -9.8E-05, 0.047188);
left_bicep_link = Body('left_bicep_link', mass, com, inertia);
left_bicep_link.attachGeometry(Mesh('MESH FILE LOCATION'));

% Left forearm link
mass = 0.93;
com = Vec3(1.8E-05, 0.076168, -0.01397);
inertia = Inertia(0.008292, -1E-06, 0, 0.000628, 0.000432, 0.008464);
left_forearm_link = Body('left_forearm_link', mass, com, inertia);
left_forearm_link.attachGeometry(Mesh('MESH FILE LOCATION'));

% Left spherical wrist 1 link
mass = 0.6781;
com = Vec3(-1E-06, 0.008486, -0.062937);
inertia = Inertia(0.001645, 0, 0, 0.001666, -0.000234, 0.000389);
left_spherical_wrist_1_link = Body('left_spherical_wrist_1_link', mass, com, inertia);
left_spherical_wrist_1_link.attachGeometry(Mesh('MESH FILE LOCATION'));

% Left spherical wrist 2 link
mass = 0.678;
com = Vec3(-1E-06, 0.046429, -0.008704);
inertia = Inertia(0.001685, 0, 0, 0.0004, 0.000255, 0.001696);
left_spherical_wrist_2_link = Body('left_spherical_wrist_2_link', mass, com, inertia);
left_spherical_wrist_2_link.attachGeometry(Mesh('MESH FILE LOCATION'));

% Left bracelet link
mass = 0.5;
com = Vec3(0.000281, 0.011402, -0.029798);
inertia = Inertia(0.000587, 3E-06, 3E-06, 0.000369, -0.000118, 0.000609);
left_bracelet_link = Body('left_bracelet_link', mass, com, inertia);
left_bracelet_link.attachGeometry(Mesh('MESH FILE LOCATION'));

% Left end effector link (massless, set mass and inertia to zero)
left_end_effector_link = Body('left_end_effector_link', 0.001, Vec3(0, 0, 0), Inertia(0, 0, 0, 0, 0, 0));

% % Left camera link (massless, set mass and inertia to zero)
% left_camera_link = Body('left_camera_link', 0.01, Vec3(0, 0, 0), Inertia(0, 0, 0, 0, 0, 0));
% 
% % Left camera depth frame (massless, set mass and inertia to zero)
% left_camera_depth_frame = Body('left_camera_depth_frame', 0.01, Vec3(0, 0, 0), Inertia(0, 0, 0, 0, 0, 0));
% 
% % Left camera color frame (massless, set mass and inertia to zero)
% left_camera_color_frame = Body('left_camera_color_frame', 0.01, Vec3(0, 0, 0), Inertia(0, 0, 0, 0, 0, 0));
% 
% % Left tool frame (massless, set mass and inertia to zero)
% left_tool_frame = Body('left_tool_frame', 0.01, Vec3(0, 0, 0), Inertia(0, 0, 0, 0, 0, 0));

%% Joints

% Joint 1: Left joint 1 (continuous)
locationInParent    = Vec3(0, 0.15805, 0);
orientationInParent = Vec3(pi()/2, 0, 0); %pi()/2, pi()/2, 0
locationInChild     = Vec3(0, 0, 0);
orientationInChild  = Vec3(0, -pi()/2, 0);
left_joint_1 = PinJoint('left_joint_1',...           % Joint Name
                        left_base_link,...         % Parent Frame (Ground)
                        locationInParent,...       % Translation in Parent Frame
                        orientationInParent,...    % Orientation in Parent Frame
                        left_shoulder_link,...     % Child Frame
                        locationInChild,...        % Translation in Child Frame
                        orientationInChild);       % Orientation in Child Frame

% Joint 2: Left joint 2 (revolute)
locationInParent2    = Vec3(0.126, 0, 0); %(0.33, 0.005375, 0)
orientationInParent2 = Vec3(pi()/2, 0, 0);
locationInChild2     = Vec3(-.205, 0, 0);
orientationInChild2  = Vec3(pi()/2, 0, 0);
left_joint_2 = PinJoint('left_joint_2',... =          % Joint Name
                        left_shoulder_link,...     % Parent Frame
                        locationInParent2,...       % Translation in Parent Frame
                        orientationInParent2,...    % Orientation in Parent Frame
                        left_bicep_link,...        % Child Frame
                        locationInChild2,...        % Translation in Child Frame
                        orientationInChild2);       % Orientation in Child Frame

% Joint 3: Left joint 3 (revolute)
locationInParent3    = Vec3(.205, 0, 0); %0, -0.41, 0
orientationInParent3 = Vec3(pi()/2, 0, 0);
locationInChild3    = Vec3(0, 0, 0);
orientationInChild3  = Vec3(pi()/2, 0, 0);
left_joint_3 = PinJoint('left_joint_3',...           % Joint Name
                        left_bicep_link,...        % Parent Frame
                        locationInParent3,...       % Translation in Parent Frame
                        orientationInParent3,...    % Orientation in Parent Frame
                        left_forearm_link,...      % Child Frame
                        locationInChild3,...        % Translation in Child Frame
                        orientationInChild3);       % Orientation in Child Frame

% Joint 4: Left joint 4 (continuous)
locationInParent4    = Vec3(.209975, 0, 0); %0, 0.20843, -0.006375
orientationInParent4 = Vec3(0, pi()/2, 0);
locationInChild4     = Vec3(0, 0, 0);
orientationInChild4  = Vec3(0, pi()/2, 0);
left_joint_4 = PinJoint('left_joint_4',...           % Joint Name
                        left_forearm_link,...      % Parent Frame
                        locationInParent4,...       % Translation in Parent Frame
                        orientationInParent4,...    % Orientation in Parent Frame
                        left_spherical_wrist_1_link,...  % Child Frame
                        locationInChild4,...        % Translation in Child Frame
                        orientationInChild4);       % Orientation in Child Frame

% Joint 5: Left joint 5 (revolute)
locationInParent5    = Vec3(.1035, 0, 0); %.207, 0, 0
orientationInParent5 = Vec3(pi()/2, 0, 0);
locationInChild5    = Vec3(.1035, 0, 0);
orientationInChild5  = Vec3(pi()/2, pi(), 0);
left_joint_5 = PinJoint('left_joint_5',...           % Joint Name
                        left_spherical_wrist_1_link,...  % Parent Frame
                        locationInParent5,...       % Translation in Parent Frame
                        orientationInParent5,...    % Orientation in Parent Frame
                        left_spherical_wrist_2_link,...  % Child Frame
                        locationInChild5,...        % Translation in Child Frame
                        orientationInChild5);       % Orientation in Child Frame

% Joint 6: Left joint 6 (continuous)
locationInParent6    = Vec3(0, 0, 0);
orientationInParent6 = Vec3(0, -pi()/2, 0);
locationInChild6     = Vec3(0, 0, 0);
orientationInChild6  = Vec3(0, 0, 0);
left_joint_6 = PinJoint('left_joint_6',...           % Joint Name
                        left_spherical_wrist_2_link,...  % Parent Frame
                        locationInParent6,...       % Translation in Parent Frame
                        orientationInParent6,...    % Orientation in Parent Frame
                        left_bracelet_link,...     % Child Frame
                        locationInChild6,...        % Translation in Child Frame
                        orientationInChild6);       % Orientation in Child Frame

% End effector joint (fixed)
locationInParent7    = Vec3(0, 0, -0.061525);
orientationInParent7 = Vec3(0, 0, 0);
locationInChild7     = Vec3(0, 0, 0);
orientationInChild7  = Vec3(0, 0, 0);
left_end_effector_joint = PinJoint('left_end_effector',...  % Joint Name
                                    left_bracelet_link,...     % Parent Frame
                                    locationInParent7,...      % Translation in Parent Frame
                                    orientationInParent7,...   % Orientation in Parent Frame
                                    left_end_effector_link,... % Child Frame
                                    locationInChild7,...       % Translation in Child Frame
                                    orientationInChild7);      % Orientation in Child Frame

% % Camera joint (fixed)
% locationInParent8    = Vec3(0, 0.05639, -0.00305);
% orientationInParent8 = Vec3(0, 0, 0);
% locationInChild8     = Vec3(0, 0, 0);
% orientationInChild8  = Vec3(0, 0, 0);
% left_camera_module_joint = PinJoint('left_camera_module',...  % Joint Name
%                                     left_end_effector_link,...  % Parent Frame
%                                     locationInParent8,...       % Translation in Parent Frame
%                                     orientationInParent8,...    % Orientation in Parent Frame
%                                     left_camera_link,...       % Child Frame
%                                     locationInChild8,...        % Translation in Child Frame
%                                     orientationInChild8);       % Orientation in Child Frame
% 
% % Camera depth joint (fixed)
% locationInParent9    = Vec3(0.0275, 0.066, -0.00305);
% orientationInParent9 = Vec3(0, 0, 0);
% locationInChild9     = Vec3(0, 0, 0);
% orientationInChild9  = Vec3(0, 0, 0);
% left_depth_module_joint = PinJoint('left_depth_module',...  % Joint Name
%                                     left_end_effector_link,...  % Parent Frame
%                                     locationInParent9,...       % Translation in Parent Frame
%                                     orientationInParent9,...    % Orientation in Parent Frame
%                                     left_camera_depth_frame,... % Child Frame
%                                     locationInChild9,...        % Translation in Child Frame
%                                     orientationInChild9);       % Orientation in Child Frame
% 
% % Camera color joint (fixed)
% locationInParent10    = Vec3(0, 0.05639, -0.00305);
% orientationInParent10 = Vec3(0, 0, 0);
% locationInChild10     = Vec3(0, 0, 0);
% orientationInChild10  = Vec3(0, 0, 0);
% left_color_module_joint = PinJoint('left_color_module',...  % Joint Name
%                                     left_end_effector_link,...  % Parent Frame
%                                     locationInParent10,...       % Translation in Parent Frame
%                                     orientationInParent10,...    % Orientation in Parent Frame
%                                     left_camera_color_frame,... % Child Frame
%                                     locationInChild10,...        % Translation in Child Frame
%                                     orientationInChild10);       % Orientation in Child Frame
% 
% % Tool frame joint (fixed)
% locationInParent11    = Vec3(0, 0, 0);
% orientationInParent11 = Vec3(0, 0, 0);
% locationInChild11     = Vec3(0, 0, 0);
% orientationInChild11  = Vec3(0, 0, 0);
% left_tool_frame_joint = PinJoint('left_tool_frame_joint',... % Joint Name
%                                   left_end_effector_link,...   % Parent Frame
%                                   locationInParent11,...        % Translation in Parent Frame
%                                   orientationInParent11,...     % Orientation in Parent Frame
%                                   left_tool_frame,...         % Child Frame
%                                   locationInChild11,...         % Translation in Child Frame
%                                   orientationInChild11);        % Orientation in Child Frame



% Add the bodies and joints to the model
model.addBody(left_base_link);
model.addBody(left_shoulder_link);
model.addBody(left_bicep_link);
model.addBody(left_forearm_link);
model.addBody(left_spherical_wrist_1_link);
model.addBody(left_spherical_wrist_2_link);
model.addBody(left_bracelet_link);
model.addBody(left_end_effector_link);
% model.addBody(left_camera_link);
% model.addBody(left_camera_depth_frame);
% model.addBody(left_camera_color_frame);
% model.addBody(left_tool_frame);

model.addJoint(left_joint_1);
model.addJoint(left_joint_2);
model.addJoint(left_joint_3);
model.addJoint(left_joint_4);
model.addJoint(left_joint_5);
model.addJoint(left_joint_6);
model.addJoint(left_end_effector_joint);
% model.addJoint(left_camera_module_joint);
% model.addJoint(left_depth_module_joint);
% model.addJoint(left_color_module_joint);
% model.addJoint(left_tool_frame_joint);

% Finalize the model
model.finalizeConnections();

outputDir = 'OUTPUT DIRECTORY LOCATION';
% mkdir(outputDir);  % Creates the directory if it doesn't exist
outputFilePath = fullfile(outputDir, 'KinovaGen3.osim');
model.print(outputFilePath);


disp('OSIM model has been successfully created.');
